-- Enable RLS
alter table companies enable row level security;
alter table suppliers enable row level security;
alter table events enable row level security;
alter table rfqs enable row level security;
alter table rfq_invites enable row level security;
alter table quotes enable row level security;

-- DEV-ONLY permissive policies
do $$ begin
  create policy dev_all_companies on companies for all using (true) with check (true);
exception when duplicate_object then null; end $$;
do $$ begin
  create policy dev_all_suppliers on suppliers for all using (true) with check (true);
exception when duplicate_object then null; end $$;
do $$ begin
  create policy dev_all_events on events for all using (true) with check (true);
exception when duplicate_object then null; end $$;
do $$ begin
  create policy dev_all_rfqs on rfqs for all using (true) with check (true);
exception when duplicate_object then null; end $$;
do $$ begin
  create policy dev_all_invites on rfq_invites for all using (true) with check (true);
exception when duplicate_object then null; end $$;
do $$ begin
  create policy dev_all_quotes on quotes for all using (true) with check (true);
exception when duplicate_object then null; end $$;
