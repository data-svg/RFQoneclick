-- Seed supplier companies
insert into companies (name, type, region) values
  ('AV Co London','supplier','London, UK'),
  ('CaterFast','supplier','London, UK'),
  ('ShieldSec','supplier','London, UK'),
  ('StageWorks','supplier','Bristol, UK'),
  ('ChefLine','supplier','Bristol, UK'),
  ('NightWatch','supplier','Bristol, UK'),
  ('LightsOn AV','supplier','Leeds, UK'),
  ('Plated','supplier','Leeds, UK'),
  ('Safeguard Pro','supplier','Leeds, UK')
on conflict do nothing;

-- Seed suppliers with services
insert into suppliers (company_id, contact_email, services, region, is_active)
select c.id,
       lower(replace(c.name,' ','_'))||'@demo.com',
       case c.name
         when 'AV Co London' then array['av','lighting']
         when 'CaterFast' then array['catering']
         when 'ShieldSec' then array['security']
         when 'StageWorks' then array['staging','av']
         when 'ChefLine' then array['catering']
         when 'NightWatch' then array['security']
         when 'LightsOn AV' then array['av','lighting']
         when 'Plated' then array['catering']
         when 'Safeguard Pro' then array['security']
         else array['other']
       end,
       c.region,
       true
from companies c where c.type='supplier';
