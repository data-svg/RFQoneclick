-- Extensions
create extension if not exists pgcrypto;
create extension if not exists "uuid-ossp";

-- Companies
create table if not exists companies (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  type text check (type in ('organizer','supplier')) not null,
  region text,
  created_at timestamptz not null default now()
);

-- Suppliers
create table if not exists suppliers (
  id uuid primary key default gen_random_uuid(),
  company_id uuid references companies(id) on delete cascade,
  contact_email text not null,
  services text[] not null default '{}',
  region text,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

-- Events
create table if not exists events (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid references companies(id) on delete set null,
  name text not null,
  event_date date,
  expected_attendance int,
  region text,
  created_at timestamptz not null default now()
);

-- RFQs
create table if not exists rfqs (
  id uuid primary key default gen_random_uuid(),
  event_id uuid references events(id) on delete cascade,
  title text not null,
  description text,
  services text[] not null default '{}',
  due_at date,
  status text not null default 'open',
  created_at timestamptz not null default now()
);

-- Invites
create table if not exists rfq_invites (
  id uuid primary key default gen_random_uuid(),
  rfq_id uuid references rfqs(id) on delete cascade,
  supplier_id uuid references suppliers(id) on delete set null,
  invite_email text not null,
  token text not null,
  status text not null default 'sent',
  created_at timestamptz not null default now()
);

-- Quotes
create table if not exists quotes (
  id uuid primary key default gen_random_uuid(),
  rfq_id uuid references rfqs(id) on delete cascade,
  supplier_id uuid references suppliers(id) on delete set null,
  invite_token text,
  supplier_email text,
  price numeric(12,2),
  currency text default 'GBP',
  notes text,
  created_at timestamptz not null default now()
);
